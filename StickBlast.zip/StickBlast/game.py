import pygame
import math
import Enemy
import Ball


def game():
    pygame.init()

    clock = pygame.time.Clock()
    FPS = 60

    SCREEN_WIDTH = 1500
    SCREEN_HEIGHT = 600

    time_score = 0
    enemy_score = 0
    high_score = 0

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Stick Blast")

    moon = pygame.image.load("moon.png")
    bg = pygame.image.load("bg.png").convert()
    bg_width = bg.get_width()

    moon_rect = moon.get_rect()
    moon_rect.topleft = (bg_width - moon_rect.width - 100, 50)
    player_idle = pygame.image.load("player_idle.png")
    player_blasting = pygame.image.load("player_blasting.png")
    player_jump = pygame.image.load("player_jump.png")
    player_crouch = pygame.image.load("player_crouch.png")
    bricks = pygame.image.load("bricks.png")
    ball_image = pygame.image.load("blasterball.png")
    monster_width = 40
    monster_height = 600
    monster_rect = pygame.Rect(0, 0, monster_width, monster_height)
    monster_rect.topleft = (0, 0)

    player_width = 50
    player_height = 100
    original_player_height = player_height
    original_player_y = SCREEN_HEIGHT - original_player_height

    player_rect = pygame.Rect(SCREEN_WIDTH // 2 - player_width // 2, original_player_y, player_width, player_height)

    jump_sound = pygame.mixer.Sound("jump.wav")
    game_over_sound = pygame.mixer.Sound("game_over.wav")
    explosion_sound = pygame.mixer.Sound("explosion.wav")
    run_sound = pygame.mixer.Sound("run.wav")
    ding_sound = pygame.mixer.Sound("ding.wav")

    scroll = 0
    tiles = math.ceil(SCREEN_WIDTH / bg_width) + 1

    is_jumping = False
    jump_count = 10

    is_crouching = False

    brick_width = 64
    brick_height = 64
    brick_speed = 3
    bricks_list = []

    player_run_frames = [
        pygame.image.load("pixilart-frames/player_run_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame7.png").convert_alpha(),
    ]
    player_run2_frames = [
        pygame.image.load("pixilart-frames2/player_run2_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame7.png").convert_alpha(),
    ]

    enemy_frames = [
        pygame.image.load("pixilart-frames3/enemy_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame7.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame8.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame9.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame10.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame11.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame12.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame13.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame14.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame15.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame16.png").convert_alpha(),
    ]

    ball_frames = [
        pygame.image.load("pixilart-frames4/blaster_hit1.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit2.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit3.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit4.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit5.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit6.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit7.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit8.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit9.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit10.png").convert_alpha(),
    ]

    monster_frames = [
        pygame.image.load("pixilart-frames5/monster1.png").convert_alpha(),
        pygame.image.load("pixilart-frames5/monster2.png").convert_alpha(),
        pygame.image.load("pixilart-frames5/monster3.png").convert_alpha(),
        pygame.image.load("pixilart-frames5/monster4.png").convert_alpha(),
    ]

    enemy_width = 64
    enemy_height = 64
    enemy_speed = 3
    enemies_list = []

    ball_list = []
    ball_height = 64
    ball_width = 64
    ball_speed = 15

    current_run_frame = 0
    animation_timer = 0
    animation_speed = 3

    current_monster_frame = 0
    monster_animation_timer = 0
    monster_animation_speed = 5

    def create_brick(x, y):
        brick_platform = pygame.Rect(x, y, brick_width, brick_height)
        bricks_list.append(brick_platform)

    for i in range(0, SCREEN_WIDTH + brick_width * 2, brick_width):
        create_brick(i, SCREEN_HEIGHT - brick_height)

    run = True
    end = False
    played_ding = False
    while run:
        clock.tick(FPS)

        time_score += 1

        for i in range(0, tiles):
            screen.blit(bg, (i * bg_width + scroll + 1, 0))

        screen.blit(moon, moon_rect.topleft)

        player_rect.x -= 3

        keys = pygame.key.get_pressed()

        if not is_crouching:
            if keys[pygame.K_a] and player_rect.left > 0:
                player_rect.x -= 8
            if keys[pygame.K_d] and player_rect.right < SCREEN_WIDTH:
                player_rect.x += 8
        elif is_crouching:
            if keys[pygame.K_a] and player_rect.left > 0:
                player_rect.x -= 4
            if keys[pygame.K_d] and player_rect.right < SCREEN_WIDTH:
                player_rect.x += 4

        if not is_jumping:
            if keys[pygame.K_w]:
                is_jumping = True
                jump_sound.play()
        else:
            if jump_count >= -10:
                neg = 1
                if jump_count < 0:
                    neg = -1
                player_rect.y -= (jump_count ** 2) * 0.5 * neg
                jump_count -= 1
            else:
                is_jumping = False
                jump_count = 10
                player_rect.y -= 5

        if keys[pygame.K_s]:
            if not is_crouching:
                is_crouching = True
                player_rect.y += original_player_height // 2
                player_rect.height //= 2
        elif is_crouching:
            is_crouching = False
            player_rect.y = original_player_y
            player_rect.height *= 2

        if not is_crouching:
            if is_jumping:
                player_model = player_jump
            elif keys[pygame.K_SPACE]:
                player_model = player_blasting
            elif keys[pygame.K_a] and keys[pygame.K_d]:
                player_model = player_idle
            elif keys[pygame.K_d]:
                player_model = player_run_frames[current_run_frame]
                animation_timer += 1
                if animation_timer >= animation_speed:
                    current_run_frame = (current_run_frame + 1) % len(player_run_frames)
                    animation_timer = 0
                    if current_run_frame == 1 or current_run_frame == 5:
                        run_sound.play()
            elif keys[pygame.K_a]:
                player_model = player_run2_frames[current_run_frame]
                animation_timer += 1
                if animation_timer >= animation_speed:
                    current_run_frame = (current_run_frame + 1) % len(player_run_frames)
                    animation_timer = 0
                    if current_run_frame == 1 or current_run_frame == 5:
                        run_sound.play()
            else:
                player_model = player_idle
        else:
            player_model = player_crouch

        screen.blit(player_model, player_rect.topleft)

        if not end:
            monster_model = monster_frames[current_monster_frame]
            monster_animation_timer += 1
            if monster_animation_timer >= monster_animation_speed:
                current_monster_frame = (current_monster_frame + 1) % len(monster_frames)
                monster_animation_timer = 0

            screen.blit(monster_model, monster_rect.topleft)

        for brick in bricks_list:
            brick.x -= brick_speed
            screen.blit(bricks, brick.topleft)

            if player_rect.colliderect(brick):
                player_rect.y = brick.y - player_rect.height
                is_jumping = False
                jump_count = 10

        if bricks_list and bricks_list[0].x < -brick_width:
            bricks_list.pop(0)
        if not bricks_list or bricks_list[-1].x < SCREEN_WIDTH:
            create_brick(SCREEN_WIDTH + brick_width, SCREEN_HEIGHT - brick_height)

        if player_rect.right < 45 or end:
            end = True
            enemies_list = []

        time_score_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Regular.ttf", 36)
        time_score_text = time_score_font.render(f"Time Score: {time_score}", True, (255, 255, 255))
        screen.blit(time_score_text, (50, 10))

        enemy_score_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Regular.ttf", 36)
        enemy_score_text = enemy_score_font.render(f"Enemy Score: {enemy_score}", True, (255, 255, 255))
        screen.blit(enemy_score_text, (50, 50))

        high_score_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Regular.ttf", 36)
        high_score_text = high_score_font.render(f"High Score: {high_score}", True, (255, 255, 255))
        screen.blit(high_score_text, (SCREEN_WIDTH - 350, 10))

        if not played_ding and enemy_score > 0 and enemy_score % 25 == 0:
            ding_sound.play()
            played_ding = True
        elif played_ding and enemy_score % 25 != 0:
            played_ding = False

        scroll -= 2

        if abs(scroll) > bg_width:
            scroll = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        for enemy in enemies_list:
            if player_rect.colliderect(enemy.rect):
                end = True

        Enemy.create_enemy(enemies_list, SCREEN_WIDTH, enemy_frames, enemy_width, enemy_height, enemy_speed)
        enemies_list = Enemy.handle_enemies(enemies_list, player_rect, screen)

        pygame.display.update()

        Ball.create_ball(ball_list, player_rect, ball_width, ball_height, ball_speed, keys[pygame.K_SPACE], ball_image)

        ball_list = Ball.update_balls(ball_list, SCREEN_WIDTH)

        pygame.display.update()

        for ball in ball_list:
            for enemy in enemies_list:
                if ball.rect.colliderect(enemy.rect) and ball.rect.right > enemy.rect.right:
                    screen.blit(ball_frames[ball.current_frame], ball.rect.topleft)
                    ball.animation_timer += 1
                    ball.speed = -3

                    if ball.animation_timer >= 1:
                        ball.current_frame = (ball.current_frame + 1) % len(ball_frames)
                        ball.animation_timer = 0

                        if ball.current_frame == 1:
                            explosion_sound.play()

                    if ball.current_frame == len(ball_frames) - 1:
                        ball_list.remove(ball)
                        enemies_list.remove(enemy)
                        enemy_score += 1

            screen.blit(ball_frames[ball.current_frame], ball.rect.topleft)

            if enemy_score > high_score:
                high_score = enemy_score

            pygame.display.update()

        if end:
            time_score = 0
            enemy_score = 0
            ball_list = []
            game_over_sound.play()
            game_over_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Bold.ttf", 74)
            game_over_text = game_over_font.render("Game Over", True, (255, 0, 0))

            restart_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Bold.ttf", 36)
            restart_text = restart_font.render("Do you want to play again? Y/N", True, "White")
            restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))

            is_jumping = False
            jump_count = 10
            is_crouching = False
            bricks_list = []
            scroll = 0

            enemies_list = []

            pygame.display.update()

            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 25))

            game_over_box_rect = pygame.Rect(
                game_over_rect.left - 15,
                game_over_rect.top - 10,
                game_over_rect.width + 25,
                game_over_rect.height + 20
            )
            pygame.draw.rect(screen, "Black", game_over_box_rect)

            restart_box_rect = pygame.Rect(
                restart_rect.left - 10,
                restart_rect.top - 10,
                restart_rect.width + 20,
                restart_rect.height + 20
            )
            pygame.draw.rect(screen, "Black", restart_box_rect)

            pygame.display.update()
            screen.blit(game_over_text, game_over_rect.topleft)

            screen.blit(restart_text, restart_rect.topleft)

            pygame.display.update()

            waiting_for_input = True
            while waiting_for_input:
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_y:
                            player_rect.x = SCREEN_WIDTH // 2 - player_width // 2
                            player_rect.y = original_player_y
                            is_jumping = False
                            jump_count = 10
                            is_crouching = False
                            bricks_list = []
                            scroll = 0
                            end = False
                            waiting_for_input = False

                        elif event.key == pygame.K_n:
                            run = False
                            waiting_for_input = False

                    if event.type == pygame.QUIT:
                        run = False
                        waiting_for_input = False

            for i in range(0, SCREEN_WIDTH + brick_width * 2, brick_width):
                create_brick(i, SCREEN_HEIGHT - brick_height)

            pygame.display.update()
            clock.tick(FPS)

    pygame.quit()
