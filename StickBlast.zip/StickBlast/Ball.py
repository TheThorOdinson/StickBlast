import pygame


class Ball:

    def __init__(self, x, y, width, height, speed, frames):
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed
        self.frames = frames
        self.animation_timer = 0
        self.current_frame = 0

    def update(self):
        self.rect.x += self.speed


def create_ball(ball_list, player_rect, ball_width, ball_height, ball_speed, player_blasting, ball_frames):
    blast_sound = pygame.mixer.Sound("blast.wav")
    if player_blasting and not ball_list:
        spawn_x = player_rect.right
        spawn_y = player_rect.centery - 20
        ball = Ball(spawn_x, spawn_y, ball_width, ball_height, ball_speed, ball_frames.copy())
        ball_list.append(ball)
        blast_sound.play()


def update_balls(ball_list, SCREEN_WIDTH):
    for ball in ball_list:
        ball.update()

    ball_list = [ball for ball in ball_list if ball.rect.left < SCREEN_WIDTH]

    return ball_list
