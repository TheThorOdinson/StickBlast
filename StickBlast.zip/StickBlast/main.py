import start


start.start_screen()
