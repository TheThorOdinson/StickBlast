import pygame
import random


class Enemy:
    def __init__(self, x, y, frames, width, height, speed, animation_speed):
        self.frames = frames
        self.current_frame = 0
        self.animation_timer = 0
        self.animation_speed = animation_speed
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed

    def update(self):
        self.rect.x -= self.speed
        self.animation_timer += 1
        if self.animation_timer >= self.animation_speed:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.animation_timer = 0

    def draw(self, screen):
        screen.blit(self.frames[self.current_frame], self.rect.topleft)


def create_enemy(enemies_list, SCREEN_WIDTH, enemy_frames, enemy_width, enemy_height, enemy_speed):
    if random.random() < 0.008:
        spawn_y = 472
        enemy = Enemy(SCREEN_WIDTH, spawn_y, enemy_frames, enemy_width, enemy_height, enemy_speed, 3)
        enemies_list.append(enemy)


def handle_enemies(enemies_list, player_rect, screen):
    for enemy in enemies_list:
        enemy.update()
        enemy.draw(screen)

        if enemy.rect.colliderect(player_rect):
            enemies_list = []

    enemies_list = [enemy for enemy in enemies_list if enemy.rect.right > 0]

    return enemies_list
