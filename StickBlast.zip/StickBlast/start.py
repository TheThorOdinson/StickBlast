import pygame
import sys
import game


def start_screen():
    pygame.init()

    width, height = 1500, 600
    bg = pygame.image.load("start_screen.png")
    bg_rect = bg.get_rect()
    bg_rect.topleft = (0, 0)
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Stick Blast")

    white = (255, 255, 255)

    font2 = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Bold.ttf", 80)
    font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Bold.ttf", 40)

    def draw_text(text, local_font, color, surface, x, y):
        text_obj = local_font.render(text, True, color)
        rect = text_obj.get_rect()
        rect.topleft = (x, y)
        surface.blit(text_obj, rect)

    def draw_button_rectangles():
        start_rect = pygame.Rect(width // 2 - 137.5, height // 2, 275, 50)
        quit_rect = pygame.Rect(width // 2 - 62.5, height // 2 + 50, 125, 50)
        pygame.draw.rect(screen, "Red", start_rect)
        pygame.draw.rect(screen, "Red", quit_rect)

    def start_menu():
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if width // 2 - 200 <= x <= width // 2 + 200 and height // 2 <= y <= height // 2 + 50:
                        return "game"
                    elif width // 2 - 200 <= x <= width // 2 + 200 and height // 2 + 50 <= y <= height // 2 + 100:
                        pygame.quit()
                        sys.exit()

            screen.blit(bg, bg_rect.topleft)

            draw_button_rectangles()

            draw_text("Stick Blast", font2, white, screen, width // 3.11, height // 4)
            draw_text("Start Game", font, white, screen, width // 2.4, height // 2)
            draw_text("Quit", font, white, screen, width // 2.135, height // 2 + 50)

            pygame.display.flip()

    selected_option = start_menu()

    if selected_option == "game":
        print("Starting the game")
        game.game()

    pygame.quit()
    sys.exit()
